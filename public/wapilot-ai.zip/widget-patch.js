// WaReply Pro — Widget Visual Patch
// Dark Green + Light Green Gradient Theme
(function patchWidgetVisuals() {
  const LOGO_URL = chrome.runtime.getURL('icons/icon128.png');

  function applyPatch() {

    // ── FLOATING ACTION BUTTON (FAB) ──
    const fab = document.getElementById('srf-master-fab');
    if (fab && !fab.dataset.patched) {
      fab.dataset.patched = '1';
      fab.style.cssText += `
        background: linear-gradient(145deg, #064d1e 0%, #0f7a35 50%, #25D366 100%) !important;
        border: 2px solid rgba(37,211,102,0.70) !important;
        box-shadow:
          0 4px 24px rgba(0,0,0,0.55),
          0 0 0 4px rgba(37,211,102,0.12),
          0 0 22px rgba(37,211,102,0.35),
          inset 0 1px 0 rgba(255,255,255,0.15) !important;
        border-radius: 50% !important;
        width: 52px !important;
        height: 52px !important;
        overflow: hidden !important;
        display: flex !important;
        align-items: center !important;
        justify-content: center !important;
        padding: 0 !important;
        transition: all 0.25s ease !important;
      `;
      const img = document.createElement('img');
      img.src = LOGO_URL;
      img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:50%';
      fab.innerHTML = '';
      fab.appendChild(img);
    }

    // ── HUD WIDGET BODY ──
    const hud = document.getElementById('srf-progress-hud');
    if (hud && !hud.dataset.patched) {
      hud.dataset.patched = '1';
      hud.style.cssText += `
        background: linear-gradient(160deg, #021a0a 0%, #053d18 45%, #0a6629 80%, #0f7a35 100%) !important;
        border: 1px solid rgba(37,211,102,0.30) !important;
        border-top: 2px solid rgba(46,229,117,0.55) !important;
        border-radius: 16px !important;
        box-shadow:
          0 16px 50px rgba(0,0,0,0.70),
          0 0 35px rgba(37,211,102,0.12),
          inset 0 1px 0 rgba(46,229,117,0.18) !important;
        color: #e0f8ec !important;
        font-family: 'Outfit', sans-serif !important;
        min-width: 250px !important;
        overflow: hidden !important;
      `;
      patchHudHeader(hud);
    }

    if (hud) {
      patchHudHeader(hud);
    }
  }

  function patchHudHeader(hud) {
    const allDivs = hud.querySelectorAll('div');
    allDivs.forEach(div => {
      const txt = div.innerText || div.textContent || '';
      if (
        (txt.includes('Auto-Reply') || txt.includes('Broadcast')) &&
        div.children.length <= 3 &&
        div.parentElement === hud
      ) {
        // ── HEADER — Dark Green to Light Green gradient ──
        div.style.cssText = `
          background: linear-gradient(90deg,
            #033d12 0%,
            #0a6629 30%,
            #12923a 60%,
            #25D366 100%) !important;
          border-bottom: 1px solid rgba(46,229,117,0.35) !important;
          padding: 10px 14px !important;
          display: flex !important;
          align-items: center !important;
          justify-content: space-between !important;
          position: relative !important;
          overflow: hidden !important;
          border-radius: 16px 16px 0 0 !important;
        `;

        // Glowing shimmer line at top of header
        if (!div.dataset.shimmer) {
          div.dataset.shimmer = '1';
          const shimmer = document.createElement('div');
          shimmer.style.cssText = `
            position:absolute;top:0;left:0;right:0;height:2px;
            background:linear-gradient(90deg,
              transparent 0%,
              rgba(46,229,117,0.4) 20%,
              rgba(100,255,160,0.95) 50%,
              rgba(46,229,117,0.4) 80%,
              transparent 100%);
            pointer-events:none;
            border-radius:16px 16px 0 0;
          `;
          div.appendChild(shimmer);
        }

        // Header text — bright white with green glow
        div.querySelectorAll('span, div').forEach(el => {
          const t = el.textContent || '';
          if (t.includes('Auto-Reply') || t.includes('Broadcast')) {
            el.style.cssText = `
              color: #ffffff !important;
              font-weight: 800 !important;
              font-size: 13px !important;
              letter-spacing: 0.3px !important;
              text-shadow:
                0 0 10px rgba(46,229,117,0.7),
                0 0 20px rgba(37,211,102,0.4) !important;
            `;
          }
        });
      }
    });
  }

  // Run immediately and keep observing
  setInterval(applyPatch, 600);
  applyPatch();
})();
