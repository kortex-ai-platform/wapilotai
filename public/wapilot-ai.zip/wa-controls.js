/* ============================================================
   WaReply Pro — Theme Toggle + Language Toggle
   100% working standalone controller
   ============================================================ */

(function () {
  'use strict';

  /* ─── THEME TOGGLE ─── */
  var html       = document.documentElement;
  var themeBtn   = document.getElementById('theme-toggle-btn');
  var iconMoon   = document.getElementById('icon-moon');
  var iconSun    = document.getElementById('icon-sun');

  function applyTheme(theme) {
    /* Set attribute on <html> — all CSS vars cascade from here */
    html.setAttribute('data-theme', theme);

    /* Swap SVG icons */
    if (iconMoon) iconMoon.style.display = (theme === 'light') ? 'none' : '';
    if (iconSun)  iconSun.style.display  = (theme === 'light') ? ''     : 'none';

    /* Persist */
    try { chrome.storage.local.set({ waReplyTheme: theme }); } catch (e) {}
  }

  /* Load saved theme on start */
  try {
    chrome.storage.local.get(['waReplyTheme'], function (r) {
      applyTheme(r.waReplyTheme || 'dark');
    });
  } catch (e) {
    applyTheme('dark');
  }

  /* Click handler */
  if (themeBtn) {
    themeBtn.addEventListener('click', function () {
      var current = html.getAttribute('data-theme') || 'dark';
      applyTheme(current === 'dark' ? 'light' : 'dark');
    });
  }


  /* ─── LANGUAGE TOGGLE (Bangla ↔ English) ─── */
  var langBtn   = document.getElementById('lang-toggle-btn');
  var currentLang = 'bn'; /* default: Bangla */

  /* ── Full translation table ── */
  var TRANSLATIONS = {
    /* selector : { bn: '...', en: '...' } */
    '#brand-badge'              : { bn: 'হোয়াটসঅ্যাপ অটোমেশন', en: 'WhatsApp Automation' },

    /* Nav tabs – match by data-tab attribute text nodes */
    '.tab-btn[data-tab="broadcast"] .tab-label'   : { bn: 'ব্রডকাস্ট',    en: 'Broadcast'     },
    '.tab-btn[data-tab="templates"] .tab-label'   : { bn: 'টেমপ্লেট',     en: 'Templates'     },
    '.tab-btn[data-tab="audience"] .tab-label'    : { bn: 'অডিয়েন্স',    en: 'Audience'      },
    '.tab-btn[data-tab="autoreply"] .tab-label'   : { bn: 'অটো রিপ্লাই', en: 'Auto Reply'    },
    '.tab-btn[data-tab="woocommerce"] .tab-label' : { bn: 'উকমার্স',     en: 'WooCommerce'   },
    '.tab-btn[data-tab="reports"] .tab-label'     : { bn: 'রিপোর্ট',     en: 'Reports'       },
    '.tab-btn[data-tab="settings"] .tab-label'    : { bn: 'সেটিংস',      en: 'Settings'      },
    '.tab-btn[data-tab="help"] .tab-label'        : { bn: 'সাহায্য',     en: 'Help'          },
    '.tab-btn[data-tab="pricing"] .tab-label'     : { bn: 'মূল্য',       en: 'Pricing'       },
  };

  /* Also support inline data-bn / data-en attributes on any element */
  function translateInlineAttrs(lang) {
    document.querySelectorAll('[data-bn]').forEach(function (el) {
      var bn = el.getAttribute('data-bn');
      var en = el.getAttribute('data-en');
      if (!bn) return;
      el.textContent = (lang === 'bn') ? bn : (en || bn);
    });
  }

  function translateSelectors(lang) {
    Object.keys(TRANSLATIONS).forEach(function (sel) {
      try {
        var el = document.querySelector(sel);
        if (!el) return;
        el.textContent = TRANSLATIONS[sel][lang] || el.textContent;
      } catch (e) {}
    });
  }

  function applyLanguage(lang) {
    currentLang = lang;

    /* Update button label: show what the OTHER language is */
    if (langBtn) langBtn.textContent = (lang === 'bn') ? 'EN' : 'বাং';

    translateSelectors(lang);
    translateInlineAttrs(lang);

    /* Persist */
    try { chrome.storage.local.set({ waReplyLang: lang }); } catch (e) {}
  }

  /* Load saved language on start */
  try {
    chrome.storage.local.get(['waReplyLang'], function (r) {
      applyLanguage(r.waReplyLang || 'bn');
    });
  } catch (e) {
    applyLanguage('bn');
  }

  /* Click handler */
  if (langBtn) {
    langBtn.addEventListener('click', function () {
      applyLanguage(currentLang === 'bn' ? 'en' : 'bn');
    });
  }

})();
