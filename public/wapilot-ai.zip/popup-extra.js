/**
 * Smart Reply Flow v4 — Extra Features
 * Dashboard, Orders Table, Telegram Notifications,
 * WhatsApp Protection Mode, Typing Effect
 */

/* ========== DASHBOARD ========== */

function initDashboard() {
  // Greeting
  const hour = new Date().getHours();
  const greetEl = document.getElementById('dash-greeting');
  if (greetEl) {
    if (hour < 12) greetEl.textContent = 'Good morning 👋';
    else if (hour < 17) greetEl.textContent = 'Good afternoon 👋';
    else greetEl.textContent = 'Good evening 👋';
  }

  // Business name
  chrome.storage.local.get(['trialUserName', 'trialBusinessName', 'licenseData'], (d) => {
    const nameEl = document.getElementById('dash-business-name');
    if (nameEl) {
      const biz = d.trialBusinessName || d.licenseData?.businessName || 'Your Business';
      nameEl.textContent = biz;
    }
  });

  loadDashboardStats();
  loadRecentActivity();
  initDashboardToggles();
}

function loadDashboardStats() {
  const today = new Date().toLocaleDateString('en-US', { timeZone: 'Asia/Dhaka' });

  chrome.storage.local.get(['autoReplyStats', 'broadcastStats'], (d) => {
    // Auto reply stats
    const arStats = d.autoReplyStats || {};
    const arToday = arStats.date === today ? (arStats.totalCount || 0) : 0;
    setEl('dash-autoreplied', arToday);

    // Broadcast stats
    const bStats = d.broadcastStats || {};
    const bToday = bStats.date === today ? (bStats.sentToday || 0) : 0;
    setEl('dash-sent-today', bToday);

    // Success rate
    const total = (bStats.successTotal || 0) + (bStats.failTotal || 0);
    const rate = total > 0 ? Math.round((bStats.successTotal / total) * 100) + '%' : '—';
    setEl('dash-success-rate', rate);
  });

  // Orders today from WC queue
  if (typeof DB !== 'undefined' && DB.getAllWcQueue) {
    DB.getAllWcQueue().then(queue => {
      const orders = (queue || []).filter(o => {
        const d = new Date(o.createdAt);
        return d.toLocaleDateString('en-US', { timeZone: 'Asia/Dhaka' }) === today;
      });
      setEl('dash-orders-today', orders.length);
    }).catch(() => {});
  }
}

function loadRecentActivity() {
  if (typeof DB === 'undefined') return;
  DB.getAllLogs().then(logs => {
    const listEl = document.getElementById('dash-recent-list');
    if (!listEl) return;
    const recent = (logs || []).slice(-8).reverse();
    if (!recent.length) {
      listEl.innerHTML = '<div class="empty-msg">No activity yet</div>';
      return;
    }
    listEl.innerHTML = recent.map(l => `
      <div class="activity-item">
        <div class="activity-dot ${l.status === 'success' ? 'green' : 'red'}"></div>
        <div style="flex:1;min-width:0">
          <span style="color:var(--text);font-weight:500">${escHtml(l.name || l.phone || 'Unknown')}</span>
          <span style="color:var(--text3);font-size:11px;margin-left:5px">${escHtml(l.source || 'Broadcast')}</span>
        </div>
        <span style="font-size:10.5px;color:var(--text3);flex-shrink:0">${l.time || ''}</span>
      </div>
    `).join('');
  }).catch(() => {});
}

function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function initDashboardToggles() {
  // AR toggle
  const arToggle = document.getElementById('dash-autoreply-toggle');
  if (arToggle) {
    chrome.storage.local.get('autoReply', d => {
      arToggle.checked = !!(d.autoReply?.enabled);
      updateARStatusText(arToggle.checked);
    });
    arToggle.addEventListener('change', () => {
      chrome.storage.local.get('autoReply', d => {
        const cfg = d.autoReply || { rules: [] };
        cfg.enabled = arToggle.checked;
        chrome.storage.local.set({ autoReply: cfg });
        updateARStatusText(arToggle.checked);
        // Sync with main autoreply-toggle
        const mainToggle = document.getElementById('autoreply-toggle');
        if (mainToggle) mainToggle.checked = arToggle.checked;
      });
    });
  }

  // Protection mode toggle
  const protToggle = document.getElementById('dash-protection-toggle');
  if (protToggle) {
    chrome.storage.local.get('protectionMode', d => {
      protToggle.checked = d.protectionMode !== false;
    });
    protToggle.addEventListener('change', () => {
      chrome.storage.local.set({ protectionMode: protToggle.checked });
    });
  }

  // Typing effect toggle
  const typingToggle = document.getElementById('dash-typing-toggle');
  if (typingToggle) {
    chrome.storage.local.get('typingEffect', d => {
      typingToggle.checked = d.typingEffect !== false;
    });
    typingToggle.addEventListener('change', () => {
      chrome.storage.local.set({ typingEffect: typingToggle.checked });
    });
  }

  // Telegram toggle
  const tgToggle = document.getElementById('dash-telegram-toggle');
  const tgBox = document.getElementById('telegram-config-box');
  if (tgToggle && tgBox) {
    chrome.storage.local.get('telegramConfig', d => {
      const cfg = d.telegramConfig || {};
      tgToggle.checked = !!(cfg.enabled);
      if (cfg.enabled) tgBox.classList.remove('hidden');
      if (cfg.botToken) document.getElementById('tg-bot-token').value = cfg.botToken;
      if (cfg.chatId) document.getElementById('tg-chat-id').value = cfg.chatId;
      updateTgStatusText(cfg);
    });
    tgToggle.addEventListener('change', () => {
      if (tgToggle.checked) tgBox.classList.remove('hidden');
      else tgBox.classList.add('hidden');
      saveTelegramConfig();
    });
  }

  // Telegram save
  const tgSaveBtn = document.getElementById('tg-save-btn');
  if (tgSaveBtn) {
    tgSaveBtn.addEventListener('click', saveTelegramConfig);
  }

  // Telegram test
  const tgTestBtn = document.getElementById('tg-test-btn');
  if (tgTestBtn) {
    tgTestBtn.addEventListener('click', testTelegramBot);
  }
}

function updateARStatusText(enabled) {
  const el = document.getElementById('dash-ar-status');
  if (el) el.textContent = enabled ? '✅ Running — scanning for unread messages' : '⏸ Disabled';
}

function updateTgStatusText(cfg) {
  const el = document.getElementById('dash-tg-desc');
  if (el) {
    el.textContent = cfg?.enabled && cfg?.botToken ? '✅ Connected — alerts active' : 'Alert on new orders';
  }
}

function saveTelegramConfig() {
  const tgToggle = document.getElementById('dash-telegram-toggle');
  const botToken = document.getElementById('tg-bot-token')?.value?.trim();
  const chatId = document.getElementById('tg-chat-id')?.value?.trim();
  const cfg = { enabled: !!(tgToggle?.checked), botToken, chatId };
  chrome.storage.local.set({ telegramConfig: cfg });
  updateTgStatusText(cfg);
  showMsg('tg-msg', '✅ Telegram settings saved!', 'green');
}

async function testTelegramBot() {
  const botToken = document.getElementById('tg-bot-token')?.value?.trim();
  const chatId = document.getElementById('tg-chat-id')?.value?.trim();
  if (!botToken || !chatId) {
    showMsg('tg-msg', '❌ Please enter Bot Token and Chat ID', 'red');
    return;
  }
  showMsg('tg-msg', '⏳ Sending test message...', '');
  try {
    const res = await sendTelegramNotification(botToken, chatId,
      '🧪 <b>Smart Reply Flow Test</b>\n\n✅ Telegram notification is working!\n\n<i>Sent from Smart Reply Flow v4</i>');
    if (res.ok) showMsg('tg-msg', '✅ Test message sent successfully!', 'green');
    else showMsg('tg-msg', '❌ Failed: ' + (res.description || 'Unknown error'), 'red');
  } catch (e) {
    showMsg('tg-msg', '❌ Error: ' + e.message, 'red');
  }
}

async function sendTelegramNotification(botToken, chatId, message) {
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text: message, parse_mode: 'HTML' })
  });
  return await resp.json();
}

function showMsg(id, text, type) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.style.color = type === 'green' ? 'var(--green)' : type === 'red' ? 'var(--red)' : 'var(--text2)';
  el.style.background = type === 'green' ? 'rgba(0,200,83,0.08)' : type === 'red' ? 'rgba(255,77,79,0.08)' : '';
}

// Quick action buttons on dashboard
function initQuickActions() {
  document.querySelectorAll('.qa-btn[data-goto]').forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-goto');
      const navBtn = document.querySelector(`.nav-btn[data-tab="${target}"]`);
      if (navBtn) navBtn.click();
    });
  });
}

/* ========== ORDERS TAB ========== */

let allOrders = [];

async function loadOrdersTab() {
  if (typeof DB === 'undefined') return;

  try {
    const queue = await DB.getAllWcQueue();
    allOrders = (queue || []).filter(o => o.orderData).map(o => {
      const od = o.orderData || {};
      return {
        id: o.id,
        orderId: od.id || od.number || '—',
        customer: od.billing?.first_name + ' ' + od.billing?.last_name || '—',
        phone: od.billing?.phone || '—',
        product: (od.line_items || []).map(i => i.name).join(', ') || '—',
        total: od.currency_symbol + (od.total || '0'),
        status: od.status || 'pending',
        date: od.date_created ? new Date(od.date_created).toLocaleDateString() : '—',
        raw: od
      };
    });
    renderOrdersTable(allOrders);
    updateOrderStats(allOrders);
  } catch (e) {
    console.error('[SRF Orders]', e);
  }
}

function renderOrdersTable(orders) {
  const tbody = document.getElementById('orders-tbody');
  if (!tbody) return;

  if (!orders.length) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-msg">No orders yet. Connect WooCommerce to start tracking.</td></tr>';
    return;
  }

  tbody.innerHTML = orders.map(o => `
    <tr>
      <td style="color:var(--green);font-weight:600">#${escHtml(String(o.orderId))}</td>
      <td>
        <div style="font-weight:500;color:var(--text)">${escHtml(o.customer)}</div>
        <div style="font-size:10.5px;color:var(--text3)">${escHtml(o.phone)}</div>
      </td>
      <td style="max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escHtml(o.product)}</td>
      <td style="font-weight:600;color:var(--text)">${escHtml(o.total)}</td>
      <td><span class="order-status-badge ${o.status}">${escHtml(o.status)}</span></td>
      <td>${escHtml(o.date)}</td>
      <td><button class="order-action-btn" data-id="${o.id}">View</button></td>
    </tr>
  `).join('');

  // Attach view handlers
  tbody.querySelectorAll('.order-action-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const order = orders.find(o => String(o.id) === btn.getAttribute('data-id'));
      if (order) openOrderModal(order);
    });
  });
}

function updateOrderStats(orders) {
  setEl('orders-count-total', orders.length);
  setEl('orders-count-pending', orders.filter(o => o.status === 'pending' || o.status === 'on-hold').length);
  setEl('orders-count-done', orders.filter(o => o.status === 'completed').length);
}

function openOrderModal(order) {
  const modal = document.getElementById('order-detail-modal');
  const body = document.getElementById('order-detail-body');
  if (!modal || !body) return;

  body.innerHTML = `
    <div class="order-detail-row"><span class="odr-label">Order ID</span><span class="odr-val">#${escHtml(String(order.orderId))}</span></div>
    <div class="order-detail-row"><span class="odr-label">Customer</span><span class="odr-val">${escHtml(order.customer)}</span></div>
    <div class="order-detail-row"><span class="odr-label">Phone</span><span class="odr-val">${escHtml(order.phone)}</span></div>
    <div class="order-detail-row"><span class="odr-label">Product</span><span class="odr-val">${escHtml(order.product)}</span></div>
    <div class="order-detail-row"><span class="odr-label">Total</span><span class="odr-val" style="color:var(--green)">${escHtml(order.total)}</span></div>
    <div class="order-detail-row"><span class="odr-label">Status</span><span class="order-status-badge ${order.status}">${escHtml(order.status)}</span></div>
    <div class="order-detail-row"><span class="odr-label">Date</span><span class="odr-val">${escHtml(order.date)}</span></div>
    ${order.raw?.billing?.city ? `<div class="order-detail-row"><span class="odr-label">City</span><span class="odr-val">${escHtml(order.raw.billing.city)}</span></div>` : ''}
  `;

  modal.classList.remove('hidden');

  // Send WA button
  const waBtn = document.getElementById('order-send-wa-btn');
  if (waBtn) {
    waBtn.onclick = () => {
      const phone = order.phone.replace(/\D/g, '');
      chrome.tabs.create({ url: `https://web.whatsapp.com/send?phone=${phone}` });
    };
  }

  document.getElementById('order-close-btn').onclick = () => modal.classList.add('hidden');
  document.getElementById('close-order-modal').onclick = () => modal.classList.add('hidden');
}

function initOrdersTab() {
  // Search
  const searchInput = document.getElementById('orders-search');
  if (searchInput) {
    searchInput.addEventListener('input', () => {
      const q = searchInput.value.toLowerCase();
      const filtered = allOrders.filter(o =>
        o.customer.toLowerCase().includes(q) ||
        o.phone.includes(q) ||
        o.product.toLowerCase().includes(q) ||
        String(o.orderId).includes(q)
      );
      renderOrdersTable(filtered);
      updateOrderStats(filtered);
    });
  }

  // Filter
  const filterSel = document.getElementById('orders-filter');
  if (filterSel) {
    filterSel.addEventListener('change', () => {
      const val = filterSel.value;
      const filtered = val === 'all' ? allOrders : allOrders.filter(o => o.status === val);
      renderOrdersTable(filtered);
      updateOrderStats(filtered);
    });
  }

  // Refresh
  const refreshBtn = document.getElementById('orders-refresh-btn');
  if (refreshBtn) refreshBtn.addEventListener('click', loadOrdersTab);

  // Export CSV
  const exportBtn = document.getElementById('orders-export-btn');
  if (exportBtn) {
    exportBtn.addEventListener('click', exportOrdersCSV);
  }
}

function exportOrdersCSV() {
  if (!allOrders.length) return;
  const headers = ['Order ID', 'Customer', 'Phone', 'Product', 'Total', 'Status', 'Date'];
  const rows = allOrders.map(o => [o.orderId, o.customer, o.phone, o.product, o.total, o.status, o.date]);
  const csv = [headers, ...rows].map(r => r.map(v => `"${String(v).replace(/"/g, '""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `orders_${new Date().toISOString().slice(0,10)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

/* ========== TELEGRAM NOTIFICATION ON NEW ORDER ========== */

// Hook into WC order processing to send Telegram alerts
function hookTelegramOnOrders() {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    // Check if a new WC order was processed
    if (changes.wcLastNewOrder) {
      const orderData = changes.wcLastNewOrder.newValue;
      if (orderData) sendTelegramOrderAlert(orderData);
    }
  });
}

async function sendTelegramOrderAlert(order) {
  const cfg = await new Promise(r => chrome.storage.local.get('telegramConfig', r));
  const tgCfg = cfg.telegramConfig;
  if (!tgCfg?.enabled || !tgCfg?.botToken || !tgCfg?.chatId) return;

  const msg = `🛒 <b>New Order Received!</b>

📦 Order: <b>#${order.id || '—'}</b>
👤 Customer: <b>${(order.billing?.first_name || '') + ' ' + (order.billing?.last_name || '')}</b>
📱 Phone: <code>${order.billing?.phone || '—'}</code>
🏙 City: ${order.billing?.city || '—'}
🛍 Product: ${(order.line_items || []).map(i => i.name).join(', ') || '—'}
💰 Total: <b>${order.currency_symbol || ''}${order.total || '0'}</b>
📋 Status: ${order.status || 'pending'}
🕐 Time: ${new Date().toLocaleTimeString('en-US', { timeZone: 'Asia/Dhaka' })}`;

  try {
    await sendTelegramNotification(tgCfg.botToken, tgCfg.chatId, msg);
    console.log('[SRF] ✅ Telegram order alert sent');
  } catch (e) {
    console.error('[SRF] Telegram alert failed:', e);
  }
}

/* ========== TAB CHANGE HOOKS ========== */

function hookTabChange() {
  // When Orders tab is clicked, load orders
  const ordersNavBtn = document.querySelector('.nav-btn[data-tab="orders"]');
  if (ordersNavBtn) {
    ordersNavBtn.addEventListener('click', () => {
      setTimeout(loadOrdersTab, 100);
    });
  }

  // When Dashboard is shown, refresh stats
  const dashNavBtn = document.querySelector('.nav-btn[data-tab="dashboard"]');
  if (dashNavBtn) {
    dashNavBtn.addEventListener('click', () => {
      setTimeout(() => { loadDashboardStats(); loadRecentActivity(); }, 100);
    });
  }
}

/* ========== INIT ========== */

document.addEventListener('DOMContentLoaded', () => {
  // Small delay to let popup.js run first
  setTimeout(() => {
    initDashboard();
    initQuickActions();
    initOrdersTab();
    hookTabChange();
    hookTelegramOnOrders();

    // Refresh dashboard stats every 30s
    setInterval(() => {
      loadDashboardStats();
    }, 30000);

    // Sync AR toggle between dashboard and auto-reply tab
    const mainARToggle = document.getElementById('autoreply-toggle');
    const dashARToggle = document.getElementById('dash-autoreply-toggle');
    if (mainARToggle && dashARToggle) {
      mainARToggle.addEventListener('change', () => {
        dashARToggle.checked = mainARToggle.checked;
        updateARStatusText(mainARToggle.checked);
      });
    }
  }, 300);
});

// ── Guide tab version ─────────────────────────────────────────
(function() {
  const el = document.getElementById('guide-version');
  if (el) {
    try { el.textContent = 'v' + chrome.runtime.getManifest().version; } catch(e) {}
  }
})();

// ── Template count badge updater ──────────────────────────────
(function patchTemplateCountBadge() {
  const orig = window.loadTemplates;
  // Hook into DB.getAllTemplates to update the count badge
  const origGet = DB && DB.getAllTemplates;
  if (!origGet) return;
  const update = () => {
    DB.getAllTemplates().then(templates => {
      const badge = document.getElementById('template-count-badge');
      if (badge) {
        badge.textContent = templates.length > 0 ? templates.length + ' টেমপ্লেট' : '';
      }
    }).catch(() => {});
  };
  document.addEventListener('DOMContentLoaded', () => setTimeout(update, 1500));
  // Also update when save button is clicked
  document.addEventListener('click', e => {
    if (e.target && e.target.id === 'save-template-btn') {
      setTimeout(update, 500);
    }
  });
})();

/* ========== SETTINGS TAB ========== */

function initSettingsTab() {
  // Load current settings
  chrome.storage.local.get(['autoReply', 'arSettings', 'protectionMode', 'typingEffect'], (d) => {
    const ar = d.autoReply || {};
    const arS = d.arSettings || {};

    // AR toggle
    const arToggle = document.getElementById('settings-ar-toggle');
    if (arToggle) {
      arToggle.checked = ar.enabled || false;
      arToggle.addEventListener('change', () => updateSettingsStatus());
    }

    // Admin mode toggle
    const adminToggle = document.getElementById('settings-admin-mode');
    if (adminToggle) {
      adminToggle.checked = arS.adminMode || false;
      adminToggle.addEventListener('change', () => {
        updateSettingsStatus();
        // If admin mode ON, pause auto-reply temporarily
        const desc = document.getElementById('settings-admin-desc');
        if (desc) {
          desc.textContent = adminToggle.checked
            ? '✅ Admin mode ON — extension will NOT send replies'
            : 'Extension pauses — admin replies manually';
        }
      });
    }

    // Timing inputs
    const minDel = document.getElementById('settings-reply-delay-min');
    const maxDel = document.getElementById('settings-reply-delay-max');
    const cooldown = document.getElementById('settings-cooldown');
    if (minDel) minDel.value = arS.replyDelayMin ?? 2;
    if (maxDel) maxDel.value = arS.replyDelayMax ?? 5;
    if (cooldown) cooldown.value = arS.cooldown ?? 300;

    // Protection toggles
    const protToggle = document.getElementById('settings-protection-toggle');
    const typingToggle = document.getElementById('settings-typing-toggle');
    const skipGroups = document.getElementById('settings-skip-groups');
    if (protToggle) protToggle.checked = d.protectionMode !== false;
    if (typingToggle) typingToggle.checked = d.typingEffect !== false;
    if (skipGroups) skipGroups.checked = ar.skipGroups !== false;

    updateSettingsStatus();
  });

  // Save button
  const saveBtn = document.getElementById('settings-save-btn');
  if (saveBtn) {
    saveBtn.addEventListener('click', saveSettingsTab);
  }

  // Hook Settings nav button
  const settingsNavBtn = document.querySelector('.nav-btn[data-tab="settings"]');
  if (settingsNavBtn) {
    settingsNavBtn.addEventListener('click', () => {
      setTimeout(() => { initSettingsTab(); }, 100);
    });
  }
}

function updateSettingsStatus() {
  const display = document.getElementById('settings-status-display');
  if (!display) return;

  const arOn = document.getElementById('settings-ar-toggle')?.checked;
  const adminOn = document.getElementById('settings-admin-mode')?.checked;

  if (!arOn) {
    display.innerHTML = '<span style="color:var(--red)">🔴 Auto-Reply is OFF</span>';
  } else if (adminOn) {
    display.innerHTML = '<span style="color:var(--amber)">🟡 Auto-Reply ON · Admin Mode Active — Extension will not send replies</span>';
  } else {
    display.innerHTML = '<span style="color:var(--green)">🟢 Auto-Reply ON · Extension is actively watching for messages</span>';
  }
}

function saveSettingsTab() {
  const arToggle = document.getElementById('settings-ar-toggle');
  const adminToggle = document.getElementById('settings-admin-mode');
  const minDel = document.getElementById('settings-reply-delay-min');
  const maxDel = document.getElementById('settings-reply-delay-max');
  const cooldown = document.getElementById('settings-cooldown');
  const protToggle = document.getElementById('settings-protection-toggle');
  const typingToggle = document.getElementById('settings-typing-toggle');
  const skipGroups = document.getElementById('settings-skip-groups');
  const msgEl = document.getElementById('settings-msg');

  const adminMode = adminToggle?.checked || false;
  const arEnabled = (arToggle?.checked || false) && !adminMode;

  // Update autoReply storage
  chrome.storage.local.get(['autoReply'], (d) => {
    const ar = d.autoReply || {};
    const updated = {
      ...ar,
      enabled: arEnabled,
      skipGroups: skipGroups?.checked !== false,
    };

    const arSettings = {
      adminMode,
      replyDelayMin: parseInt(minDel?.value || '2'),
      replyDelayMax: parseInt(maxDel?.value || '5'),
      cooldown: parseInt(cooldown?.value || '300'),
    };

    chrome.storage.local.set({
      autoReply: updated,
      arSettings,
      protectionMode: protToggle?.checked !== false,
      typingEffect: typingToggle?.checked !== false,
    }, () => {
      // Sync main AR toggle
      const mainToggle = document.getElementById('autoreply-toggle');
      if (mainToggle) mainToggle.checked = arEnabled;
      const dashToggle = document.getElementById('dash-autoreply-toggle');
      if (dashToggle) dashToggle.checked = arEnabled;

      if (msgEl) {
        msgEl.textContent = '✅ Settings saved!';
        msgEl.style.color = 'var(--green)';
        setTimeout(() => { msgEl.textContent = ''; }, 2500);
      }

      updateSettingsStatus();
    });
  });
}

/* ========== FLOATING AUTO-REPLY WIDGET COLOR ========== */

function patchFloatingWidgetStyle() {
  // Inject CSS to restyle the floating widget to green theme + logo
  const existing = document.getElementById('wareply-widget-style');
  if (existing) return;

  const style = document.createElement('style');
  style.id = 'wareply-widget-style';
  style.textContent = `
    /* WaReply Pro floating widget green style */
    #srf-progress-hud {
      background: linear-gradient(145deg, #0d1a12, #102016) !important;
      border: 1.5px solid rgba(37,211,102,0.35) !important;
      box-shadow: 0 8px 32px rgba(0,0,0,0.6), 0 0 20px rgba(37,211,102,0.15) !important;
      border-radius: 16px !important;
      min-width: 220px !important;
    }
    /* FAB button — green glow */
    #srf-master-fab {
      background: linear-gradient(135deg, #25D366, #128C7E) !important;
      border: 2px solid rgba(255,255,255,0.3) !important;
      box-shadow: 0 4px 20px rgba(37,211,102,0.5), 0 0 0 4px rgba(37,211,102,0.15) !important;
      border-radius: 50% !important;
      width: 52px !important;
      height: 52px !important;
      overflow: hidden !important;
    }
  `;
  document.head.appendChild(style);
}

// Init Settings when DOM ready
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    initSettingsTab();
    patchFloatingWidgetStyle();
  }, 400);
});
