// WaReply Pro - Compatibility Bridge
// Maps logic popup.js class expectations to UI popup.html class names
(function() {
  // Patch querySelectorAll and querySelector for tab-btn -> nav-btn mapping
  const _origQSA = document.querySelectorAll.bind(document);
  const _origQS = document.querySelector.bind(document);
  
  document.querySelectorAll = function(sel) {
    const mapped = sel
      .replace(/\.tab-btn/g, '.nav-btn')
      .replace(/\.tab-content/g, '.tab');
    return _origQSA(mapped);
  };
  
  document.querySelector = function(sel) {
    const mapped = sel
      .replace(/\.tab-btn/g, '.nav-btn')
      .replace(/\.tab-content/g, '.tab');
    return _origQS(mapped);
  };
  
  // Also patch Element.prototype for chained calls
  const _elemQSA = Element.prototype.querySelectorAll;
  const _elemQS = Element.prototype.querySelector;
  
  Element.prototype.querySelectorAll = function(sel) {
    const mapped = sel
      .replace(/\.tab-btn/g, '.nav-btn')
      .replace(/\.tab-content/g, '.tab');
    return _elemQSA.call(this, mapped);
  };
  
  Element.prototype.querySelector = function(sel) {
    const mapped = sel
      .replace(/\.tab-btn/g, '.nav-btn')
      .replace(/\.tab-content/g, '.tab');
    return _elemQS.call(this, mapped);
  };
})();

// Settings tab support — ensure nav switching works
(function addSettingsTabSupport() {
  document.addEventListener('DOMContentLoaded', () => {
    // Wire up nav-btn clicks for the new Settings tab
    document.querySelectorAll('.nav-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const tab = btn.dataset.tab;
        if (!tab) return;
        // Remove active from all nav buttons
        document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
        // Remove active from all tab sections
        document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
        // Set active on clicked button
        btn.classList.add('active');
        // Show the matching tab
        const tabEl = document.getElementById('tab-' + tab);
        if (tabEl) tabEl.classList.add('active');
      });
    });
  });
})();
