# 🚀 Smart Reply Flow v4 — Complete Setup Guide
## Stack: GitHub + Supabase + Vercel (100% Free)

---

## 📋 What You Need
- GitHub account (free) → https://github.com
- Supabase account (free) → https://supabase.com
- Vercel account (free) → https://vercel.com
- Google Chrome browser

---

## STEP 1 — Set Up Supabase Database

### 1.1 — Create Project
1. Go to https://supabase.com → Sign Up → New Project
2. Name: `smart-reply-flow`
3. Password: Choose a strong password (save it!)
4. Region: **Southeast Asia (Singapore)**
5. Click "Create new project"

### 1.2 — Create Database Tables
Go to Supabase Dashboard → **SQL Editor** → Run this SQL:

```sql
-- Users / Licenses Table
CREATE TABLE licenses (
  id            BIGSERIAL PRIMARY KEY,
  wa_number     TEXT UNIQUE NOT NULL,
  license_key   TEXT UNIQUE,
  plan          TEXT DEFAULT 'trial',
  status        TEXT DEFAULT 'active',
  user_name     TEXT,
  business_name TEXT,
  trial_start   TIMESTAMPTZ,
  trial_days    INT DEFAULT 3,
  activated_at  TIMESTAMPTZ,
  expires_at    TIMESTAMPTZ,
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- Payment Requests Table
CREATE TABLE payments (
  id            BIGSERIAL PRIMARY KEY,
  wa_number     TEXT NOT NULL,
  sender_info   TEXT,
  trx_id        TEXT,
  plan          TEXT,
  amount        TEXT,
  customer_name TEXT,
  business_name TEXT,
  status        TEXT DEFAULT 'pending',
  created_at    TIMESTAMPTZ DEFAULT now()
);

-- App Settings Table
CREATE TABLE app_settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

-- Insert default settings
INSERT INTO app_settings (key, value) VALUES
  ('bkash_number',       '01712345678'),
  ('nagad_number',       '01912345678'),
  ('price_monthly',      '950'),
  ('price_yearly',       '4500'),
  ('price_lifetime',     '14500'),
  ('support_whatsapp',   '01712345678'),
  ('tutorial_youtube',   'https://youtube.com/your-channel'),
  ('website_link',       'https://yourwebsite.com'),
  ('update_version',     '4.0.0'),
  ('update_link',        'https://yourwebsite.com/download'),
  ('broadcast_guide',    'https://yourwebsite.com/guide');

-- Row Level Security
ALTER TABLE licenses    ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments    ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read settings"
  ON app_settings FOR SELECT USING (true);
```

### 1.3 — Get API Keys
- Supabase → Settings → API
- Copy **URL**: `https://xxxxx.supabase.co`
- Copy **anon/public key** AND **service_role key**

---

## STEP 2 — Create GitHub Repository

### 2.1 — Create Repo
1. GitHub → New repository
2. Name: `srf-backend`
3. Set to **Private**
4. Create repository

### 2.2 — File Structure
```
srf-backend/
├── api/
│   ├── trial/start.js
│   ├── trial/check.js
│   ├── license/verify.js
│   ├── license/bind.js
│   ├── license/fetch.js
│   ├── payment/submit.js
│   ├── payment/pending.js
│   └── settings/public.js
├── lib/supabase.js
├── package.json
└── vercel.json
```

### 2.3 — package.json
```json
{
  "name": "srf-backend",
  "version": "1.0.0",
  "dependencies": {
    "@supabase/supabase-js": "^2.39.0"
  }
}
```

### 2.4 — vercel.json
```json
{
  "version": 2,
  "functions": {
    "api/**/*.js": { "runtime": "nodejs18.x" }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "Access-Control-Allow-Origin", "value": "*" },
        { "key": "Access-Control-Allow-Methods", "value": "GET,POST,OPTIONS" },
        { "key": "Access-Control-Allow-Headers", "value": "Content-Type" }
      ]
    }
  ]
}
```

### 2.5 — lib/supabase.js
```javascript
const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);
module.exports = { supabase };
```

### 2.6 — api/trial/start.js
```javascript
const { supabase } = require('../../lib/supabase');
module.exports = async (req, res) => {
  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ success: false });
  const { waNumber, userName, businessName } = req.body;
  if (!waNumber) return res.status(400).json({ success: false, reason: 'WA number required' });
  const { data: existing } = await supabase.from('licenses').select('*').eq('wa_number', waNumber).single();
  if (existing) {
    if (existing.status === 'active' && existing.plan === 'trial') {
      const elapsed = (Date.now() - new Date(existing.trial_start).getTime()) / 86400000;
      const daysLeft = Math.max(0, existing.trial_days - Math.floor(elapsed));
      return res.json({ success: true, valid: daysLeft > 0, daysLeft, isTrial: true });
    }
    return res.json({ success: false, reason: 'Trial already used on this number.' });
  }
  const { error } = await supabase.from('licenses').insert({
    wa_number: waNumber, user_name: userName, business_name: businessName,
    plan: 'trial', status: 'active', trial_start: new Date().toISOString(), trial_days: 3
  });
  if (error) return res.json({ success: false, reason: 'Server error.' });
  res.json({ success: true, valid: true, daysLeft: 3, isTrial: true });
};
```

### 2.7 — api/trial/check.js
```javascript
const { supabase } = require('../../lib/supabase');
module.exports = async (req, res) => {
  if (req.method === 'OPTIONS') return res.status(200).end();
  const { waNumber } = req.query;
  if (!waNumber) return res.json({ valid: false, isNew: true });
  const { data } = await supabase.from('licenses').select('*').eq('wa_number', waNumber).single();
  if (!data) return res.json({ valid: false, isNew: true, isTrial: false });
  if (data.plan === 'trial') {
    const elapsed = (Date.now() - new Date(data.trial_start).getTime()) / 86400000;
    const daysLeft = Math.max(0, data.trial_days - Math.floor(elapsed));
    return res.json({ valid: daysLeft > 0, isTrial: true, daysLeft, isNew: false });
  }
  if (data.plan === 'lifetime') return res.json({ valid: true, isTrial: false, daysLeft: 9999, isNew: false });
  const expired = data.expires_at && new Date(data.expires_at) < new Date();
  res.json({ valid: !expired, isTrial: false, isNew: false });
};
```

### 2.8 — api/license/verify.js
```javascript
const { supabase } = require('../../lib/supabase');
module.exports = async (req, res) => {
  if (req.method === 'OPTIONS') return res.status(200).end();
  const { key, waNumber } = req.query;
  if (!key) return res.json({ valid: false, reason: 'License key required' });
  const { data } = await supabase.from('licenses').select('*').eq('license_key', key).single();
  if (!data) return res.json({ valid: false, reason: 'Invalid license key.' });
  if (data.status === 'expired') return res.json({ valid: false, reason: 'License expired.' });
  if (data.plan !== 'lifetime' && data.expires_at && new Date(data.expires_at) < new Date()) {
    await supabase.from('licenses').update({ status: 'expired' }).eq('id', data.id);
    return res.json({ valid: false, reason: 'License has expired.' });
  }
  res.json({
    valid: true,
    data: {
      plan: { stringValue: data.plan },
      linkedNumber: { stringValue: data.wa_number },
      activationDate: { timestampValue: data.activated_at },
      duration: { integerValue: data.plan === 'lifetime' ? 9999 : 365 }
    }
  });
};
```

### 2.9 — api/settings/public.js
```javascript
const { supabase } = require('../../lib/supabase');
module.exports = async (req, res) => {
  if (req.method === 'OPTIONS') return res.status(200).end();
  const { data } = await supabase.from('app_settings').select('*');
  const settings = {};
  (data || []).forEach(row => { settings[row.key] = row.value; });
  res.json({
    success: true,
    data: {
      bkashNumber: settings.bkash_number,
      nagadNumber: settings.nagad_number,
      priceMonthly: settings.price_monthly,
      priceYearly: settings.price_yearly,
      priceLifetime: settings.price_lifetime,
      supportWhatsapp: settings.support_whatsapp,
      tutorialYoutube: settings.tutorial_youtube,
      websiteLink: settings.website_link,
      updateVersion: settings.update_version,
      updateLink: settings.update_link,
      broadcastGuideLink: settings.broadcast_guide
    }
  });
};
```

---

## STEP 3 — Deploy to Vercel

### 3.1 — Connect
1. Go to https://vercel.com → Sign Up with GitHub
2. Click "New Project" → Import `srf-backend` repo
3. Framework: **Other**
4. Root Directory: `/`
5. Click Deploy

### 3.2 — Environment Variables
Vercel Dashboard → Settings → Environment Variables:

| Key | Value |
|-----|-------|
| `SUPABASE_URL` | `https://xxxxx.supabase.co` |
| `SUPABASE_SERVICE_KEY` | service_role key from Supabase |

⚠️ Use **service_role** key, NOT anon key!

### 3.3 — Redeploy
Vercel → Deployments → Redeploy

Your API URL: `https://srf-backend.vercel.app/api`

---

## STEP 4 — Update Extension

In `license.js` find and update:
```javascript
const API_BASE = "https://srf-backend.vercel.app/api";
```

---

## STEP 5 — Load Extension in Chrome

1. Open Chrome → go to `chrome://extensions`
2. Enable **Developer Mode** (top right toggle)
3. Click **"Load unpacked"**
4. Select the `srf_v4` folder
5. Extension is loaded! ✅

---

## STEP 6 — Admin Panel (Supabase)

### Issue a License
```sql
INSERT INTO licenses (wa_number, license_key, plan, status, activated_at, expires_at, user_name)
VALUES (
  '8801712345678',
  'SRF-' || upper(substring(md5(random()::text) from 1 for 4)) || '-' ||
            upper(substring(md5(random()::text) from 1 for 4)) || '-' ||
            upper(substring(md5(random()::text) from 1 for 4)),
  'monthly', 'active', now(), now() + interval '30 days', 'Customer Name'
);
```

### Approve Payment & Issue License
```sql
-- 1. View pending payments
SELECT * FROM payments WHERE status = 'pending' ORDER BY created_at DESC;

-- 2. Approve payment
UPDATE payments SET status = 'approved' WHERE id = 5;

-- 3. Create license for customer
INSERT INTO licenses (wa_number, license_key, plan, status, activated_at, expires_at)
VALUES (
  '880171XXXXXXX',
  'SRF-XXXX-YYYY-ZZZZ',
  'yearly', 'active', now(), now() + interval '365 days'
);
```

---

## STEP 7 — Telegram Notification Setup

1. Open extension → **Dashboard** tab
2. Enable **Telegram Notifications** toggle
3. Get a Bot Token: Message @BotFather on Telegram → `/newbot`
4. Get Chat ID: Message @userinfobot on Telegram
5. Enter Bot Token and Chat ID in the extension
6. Click **Send Test** to verify
7. Click **Save**

Now you'll get instant Telegram alerts for every new WooCommerce order!

---

## 📊 Recommended Stack Comparison

| Service | Purpose | Free Limit | Verdict |
|---------|---------|------------|---------|
| **Supabase** | Database | 500MB, 50K rows | ✅ Best |
| **Vercel** | API hosting | 100GB/month | ✅ Best |
| **GitHub** | Code storage | Unlimited | ✅ Best |
| Firebase/Firestore | Alternative DB | 1GB | Good but more complex |

**Winner: Supabase + Vercel + GitHub** — Easiest setup, best free tier, PostgreSQL power.

---

## ❓ Troubleshooting

**Extension not working?**
→ Check chrome://extensions → Errors button for error messages

**API returning errors?**
→ Vercel → Functions → Logs for detailed error messages

**CORS error?**
→ Check vercel.json headers are correctly set

**Supabase connection failed?**
→ Check Environment Variables in Vercel settings

**WhatsApp automation not working?**
→ Make sure you're on web.whatsapp.com (not app.whatsapp.com)

---

*Smart Reply Flow v4.0 — Professional WhatsApp Automation*
*Stack: Supabase + Vercel + GitHub*
