/* Wapilot AI — secure license layer.
   No Supabase keys live here. The extension only talks to the Wapilot AI backend. */
const WAPILOT_API = 'https://project--caeaaf3c-43dd-46b6-b073-dddb81936ae5.lovable.app/api/public/ext';

function _wapStore(get) {
  return new Promise((res) => chrome.storage.local.get(get, res));
}
function _wapSet(obj) {
  return new Promise((res) => chrome.storage.local.set(obj, res));
}

async function getDeviceId() {
  const { wapilotDeviceId } = await _wapStore(['wapilotDeviceId']);
  if (wapilotDeviceId) return wapilotDeviceId;
  const id = 'dev_' + (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '_' + Math.random().toString(36).slice(2));
  await _wapSet({ wapilotDeviceId: id });
  return id;
}

async function apiPost(path, body) {
  try {
    const r = await fetch(`${WAPILOT_API}/${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return await r.json();
  } catch (e) {
    return { valid: false, success: false, reason: 'Network error. ইন্টারনেট সংযোগ চেক করুন।' };
  }
}
async function apiGet(path, params) {
  try {
    const qs = new URLSearchParams(params || {}).toString();
    const r = await fetch(`${WAPILOT_API}/${path}${qs ? '?' + qs : ''}`);
    return await r.json();
  } catch (e) {
    return { valid: false, success: false, reason: 'Network error.' };
  }
}

function toLegacy(res) {
  // Map backend response to the shape the popup UI expects.
  let duration = 9999;
  if (res.expiresAt) {
    duration = Math.max(0, Math.ceil((new Date(res.expiresAt).getTime() - Date.now()) / 86400000));
  }
  return {
    plan: { stringValue: res.plan || 'pro' },
    duration: { integerValue: String(duration) },
    activationDate: { timestampValue: new Date().toISOString() },
    devices: res.devices || null,
    user: res.user || null,
  };
}

const LicenseManager = {
  async verifyLicense(key, phone) {
    if (!key) return { valid: false, reason: 'License key required.' };
    const deviceId = await getDeviceId();
    const res = await apiPost('license/activate', { key: key.trim().toUpperCase(), deviceId, waNumber: phone || undefined });
    if (!res.valid) return { valid: false, reason: res.reason || 'Invalid Wapilot AI license.' };
    await _wapSet({ wapilotLicenseKey: key.trim().toUpperCase(), wapilotLicenseCheckedAt: Date.now() });
    return { valid: true, data: toLegacy(res) };
  },

  async revalidate() {
    const { wapilotLicenseKey } = await _wapStore(['wapilotLicenseKey']);
    if (!wapilotLicenseKey) return { valid: false, reason: 'No license key.' };
    const deviceId = await getDeviceId();
    const res = await apiPost('license/validate', { key: wapilotLicenseKey, deviceId });
    await _wapSet({ wapilotLicenseCheckedAt: Date.now() });
    if (!res.valid) return { valid: false, reason: res.reason || 'License is not valid.' };
    return { valid: true, data: toLegacy(res) };
  },

  async deactivateDevice() {
    const { wapilotLicenseKey } = await _wapStore(['wapilotLicenseKey']);
    if (!wapilotLicenseKey) return { success: false };
    const deviceId = await getDeviceId();
    const res = await apiPost('license/deactivate', { key: wapilotLicenseKey, deviceId });
    if (res.success) await _wapSet({ wapilotLicenseKey: '' });
    return res;
  },

  async listDevices() {
    const { wapilotLicenseKey } = await _wapStore(['wapilotLicenseKey']);
    if (!wapilotLicenseKey) return { success: false, devices: [] };
    return apiPost('device/list', { key: wapilotLicenseKey });
  },

  async bindLicense(key, phone) {
    const res = await this.verifyLicense(key, phone);
    return !!res.valid;
  },

  async fetchBoundLicense(phone) {
    const { wapilotLicenseKey } = await _wapStore(['wapilotLicenseKey']);
    if (!wapilotLicenseKey) return { valid: false };
    const res = await this.revalidate();
    if (!res.valid) return { valid: false, reason: res.reason };
    return { valid: true, key: wapilotLicenseKey, data: res.data };
  },

  async checkTrial(phone) {
    if (!phone) return { valid: false, isTrial: false, daysLeft: 0 };
    const bound = await this.fetchBoundLicense(phone);
    if (bound.valid) {
      const d = parseInt(bound.data.duration.integerValue || '0', 10);
      return { valid: true, isTrial: false, daysLeft: d };
    }
    return apiGet('trial/check', { waNumber: phone });
  },

  async startTrial(phone, name, biz) {
    if (!phone) return { valid: false, reason: 'WhatsApp number required.' };
    return apiPost('trial/start', { waNumber: phone, userName: name || undefined, businessName: biz || undefined });
  },

  async submitPaymentRequest(phone, senderInfo, trxId, plan, amount, customerName, businessName) {
    return apiPost('payment/submit', {
      waNumber: phone,
      senderInfo,
      trxId,
      plan,
      amount: amount ? String(amount) : undefined,
      customerName: customerName || undefined,
      businessName: businessName || undefined,
    });
  },

  async checkPendingPayment(phone) {
    const res = await apiGet('payment/pending', { waNumber: phone });
    return !!res.pending;
  },

  async getPaymentSettings() {
    const res = await apiGet('settings/public');
    const s = (res && res.settings) || {};
    return {
      bkashNumber: s.bkashNumber || '',
      nagadNumber: s.nagadNumber || '',
      bkashInstruction: s.bkashInstruction || '',
      nagadInstruction: s.nagadInstruction || '',
      supportWhatsapp: s.supportWhatsapp || '',
      tutorialYoutube: s.tutorialYoutube || '',
      supportChannel: s.supportWhatsapp || '',
      websiteLink: s.websiteLink || '',
      broadcastGuideLink: s.broadcastGuideLink || '',
      updateVersion: s.updateVersion || '',
      updateLink: s.updateLink || '',
      priceMonthly: s.priceMonthly || '0',
      regPriceMonthly: s.priceMonthly || '0',
      priceYearly: s.priceYearly || '0',
      regPriceYearly: s.priceYearly || '0',
      priceLifetime: s.priceLifetime || '0',
      regPriceLifetime: s.priceLifetime || '0',
    };
  },

  async logEvent(type, phone, meta) {
    return apiPost('events', { type, waNumber: phone || undefined, meta: meta || undefined });
  },
};
