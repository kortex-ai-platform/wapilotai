// WaReply Pro — License Manager (backend-connected)
// Talks to the WaReply Pro web backend for trial, license and payment flows.
const WAREPLY_API_BASE = "https://project--caeaaf3c-43dd-46b6-b073-dddb81936ae5.lovable.app/api/public/ext";

const LicenseManager = {
  async _post(path, body) {
    const res = await fetch(`${WAREPLY_API_BASE}/${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body || {}),
    });
    return res.json();
  },
  async _get(path) {
    const res = await fetch(`${WAREPLY_API_BASE}/${path}`);
    return res.json();
  },

  _toLegacyData(license) {
    if (!license) return null;
    const days = license.durationDays || 0;
    return {
      plan: { stringValue: license.plan || "trial" },
      duration: { integerValue: String(days) },
      activationDate: { timestampValue: license.activatedAt || new Date().toISOString() },
    };
  },

  async verifyLicense(key, phone) {
    try {
      const r = await this._post("license/verify", { key, waNumber: phone });
      if (r && r.valid) {
        return { valid: true, data: this._toLegacyData(r.license) };
      }
      return { valid: false, reason: (r && r.reason) || "Invalid license" };
    } catch (e) {
      return { valid: false, reason: "Network error" };
    }
  },

  async bindLicense(key, phone) {
    try {
      const r = await this._post("license/bind", { key, waNumber: phone });
      return !!(r && r.success);
    } catch (e) {
      return false;
    }
  },

  async checkTrial(phone) {
    try {
      const r = await this._post("trial/check", { waNumber: phone });
      return {
        valid: !!r.valid,
        isTrial: !!r.isTrial,
        daysLeft: typeof r.daysLeft === "number" ? r.daysLeft : 0,
        reason: r.reason || "",
      };
    } catch (e) {
      return { valid: false, isTrial: false, daysLeft: 0, reason: "Network error" };
    }
  },

  async startTrial(phone, name, biz) {
    try {
      const r = await this._post("trial/start", { waNumber: phone, userName: name || "", businessName: biz || "" });
      return {
        valid: !!r.valid,
        isTrial: !!r.isTrial,
        daysLeft: typeof r.daysLeft === "number" ? r.daysLeft : 0,
        reason: r.reason || "",
      };
    } catch (e) {
      return { valid: false, isTrial: false, daysLeft: 0, reason: "Network error" };
    }
  },

  async submitPaymentRequest(waNumber, senderInfo, trxId, plan, amount, customerName, businessName) {
    try {
      const r = await this._post("payment/submit", {
        waNumber, senderInfo, trxId, plan, amount, customerName, businessName,
      });
      return { success: !!r.success, reason: r.reason || "" };
    } catch (e) {
      return { success: false, reason: "Network error. আবার চেষ্টা করুন।" };
    }
  },

  async checkPendingPayment(phone) {
    try {
      const r = await this._post("payment/pending", { waNumber: phone });
      return !!r.pending;
    } catch (e) {
      return false;
    }
  },

  async getPaymentSettings() {
    const empty = {
      bkashNumber: "", nagadNumber: "", bkashInstruction: "", nagadInstruction: "",
      supportWhatsapp: "", tutorialYoutube: "", supportChannel: "", websiteLink: "",
      broadcastGuideLink: "", updateVersion: "", updateLink: "",
      priceMonthly: "0", regPriceMonthly: "0", priceYearly: "0", regPriceYearly: "0",
      priceLifetime: "0", regPriceLifetime: "0",
    };
    try {
      const r = await this._get("settings/public");
      const s = (r && r.settings) || {};
      return Object.assign(empty, {
        bkashNumber: s.bkash_number || "",
        nagadNumber: s.nagad_number || "",
        bkashInstruction: s.bkash_instruction || "",
        nagadInstruction: s.nagad_instruction || "",
        supportWhatsapp: s.support_whatsapp || "",
        tutorialYoutube: s.tutorial_youtube || "",
        websiteLink: s.website_link || "",
        broadcastGuideLink: s.broadcast_guide || "",
        updateVersion: s.update_version || "",
        updateLink: s.update_link || "",
        priceMonthly: s.price_monthly || "0",
        priceYearly: s.price_yearly || "0",
        priceLifetime: s.price_lifetime || "0",
      });
    } catch (e) {
      return empty;
    }
  },

  async fetchBoundLicense(phone) {
    try {
      const r = await this._post("license/fetch", { waNumber: phone });
      if (r && r.valid) {
        return { valid: true, key: r.key, data: this._toLegacyData(r.license) };
      }
      return { valid: false, reason: (r && r.reason) || "No active license" };
    } catch (e) {
      return { valid: false, reason: "Network error" };
    }
  },
};

// Analytics: fire-and-forget event tracking
function wareplyTrack(eventName, metadata) {
  try {
    chrome.storage.local.get(["waNumber"], (res) => {
      fetch(`${WAREPLY_API_BASE}/events`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          waNumber: (res && res.waNumber) || "unknown",
          eventName,
          metadata: metadata || {},
        }),
      }).catch(() => {});
    });
  } catch (e) {}
}
